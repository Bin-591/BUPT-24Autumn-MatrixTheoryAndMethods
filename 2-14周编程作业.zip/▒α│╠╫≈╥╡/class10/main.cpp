#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define ROWS 2
#define COLS 2
#define N 200 // 级数展开的项数

// 计算矩阵的乘积
void matrix_multiply(double result[ROWS][COLS], double A[ROWS][COLS], double B[ROWS][COLS]) {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            result[i][j] = 0;
            for (int k = 0; k < COLS; k++) {
                result[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

// 计算矩阵的指数函数
void matrix_exp(double A[ROWS][COLS], double exp_A[ROWS][COLS], int N) {
double I[ROWS][COLS] = {{1, 0}, {0, 1}}; // 单位矩阵
double J[ROWS][COLS]; // 若尔当标准形矩阵
double P[ROWS][COLS], invP[ROWS][COLS]; // 相似变换矩阵及其逆矩阵

// 这里简化处理，假设A已经是上三角矩阵（即若尔当标准形）
for (int i = 0; i < ROWS; i++) {
for (int j = 0; j < COLS; j++) {
J[i][j] = A[i][j];
}
}

// 计算P和invP，这里省略了计算过程
// 在实际情况中，需要计算A的若尔当标准形和相似变换矩阵

double Jk[ROWS][COLS]; // J的k次幂
double fJ[ROWS][COLS] = {0}; // f(J)的近似值

// 初始化Jk为单位矩阵
for (int i = 0; i < ROWS; i++) {
for (int j = 0; j < COLS; j++) {
Jk[i][j] = I[i][j];
}
}

exp_A[0][0] = 1; // e^0 = 1
for (int k = 1; k <= N; k++) {
matrix_multiply(Jk, Jk, J); // 计算Jk
fJ[0][0] += pow(1.0 / k, 1) * Jk[0][0]; // 假设f(J) = J
fJ[0][1] += pow(1.0 / k, 1) * Jk[0][1];
fJ[1][0] += pow(1.0 / k, 1) * Jk[1][0];
fJ[1][1] += pow(1.0 / k, 1) * Jk[1][1];
}

// 计算f(A) = P f(J) P^-1
double fA[ROWS][COLS];
matrix_multiply(fA, P, fJ); // 假设P是单位矩阵，省略了计算过程
matrix_multiply(exp_A, fA, invP); // 假设invP是单位矩阵，省略了计算过程
}

int main() {
    double A[ROWS][COLS] = {{1, 1}, {0, 0}};
    double exp_A[ROWS][COLS];

    matrix_exp(A, exp_A, N);

    printf("e^A = \n");
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            printf("%lf ", exp_A[i][j])