#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define DIM 2 // 定义向量空间的维度

// 定义内积函数
double inner_product(double u[], double v[]) {
    double sum = 0.0;
    for (int i = 0; i < DIM; i++) {
        sum += u[i] * v[i];
    }
    return sum;
}

// 线性变换函数
void mapping(double x[], double y[]) {
    // 根据实际变换填充
    y[0] = 2 * x[0] + 5 * x[1];
    y[1] = 4 * x[0] + 2 * x[1];
}

// 线性变换的函数
void function(void (*mapping)(double[], double[]), double x[]) {
    double y[DIM];
    double basis[1000][DIM]; // 增加一个足够大的数组来存储基
    int N = 3;

    // 初始化基
    for (int i = 0; i < DIM; i++) {
        basis[0][i] = x[i];
    }

    for (int n = 0; n < N; n++) {
        mapping(basis[n], basis[n + 1]);
    }

    // 假设 f(T)(x) 是 basis 的最后一个元素
    for (int i = 0; i < DIM; i++) {
        x[i] = basis[N][i];
    }
}

int main() {
    // 初始化向量
    double x[DIM] = {4, -4};

    // 直接计算 f(T)(x)
    clock_t start, end;
    double cpu_time1, cpu_time2;
    start = clock();
    function(mapping, x);
    end = clock();
    cpu_time1 = (double)(end - start) / CLOCKS_PER_SEC;
    printf("直接计算 f(T)(x):\n");
    for (int i = 0; i < DIM; i++) {
        printf("%lf\n", x[i]);
    }
    printf("计算时间：%lf\n", cpu_time1);

    // 利用理论框架计算 f(T)(x)
    start = clock();
    double y[DIM];
    mapping(x, y);
    end = clock();
    cpu_time2 = (double)(end - start) / CLOCKS_PER_SEC;
    printf("利用理论框架计算 f(T)(x):\n");
    for (int i = 0; i < DIM; i++) {
        printf("%lf\n", y[i]);
    }
    printf("计算时间：%lf\n", cpu_time2);

    // 比较计算时间
    int N = 1000;
    start = clock();
    for (int n = 0; n < N; n++) {
        double a[DIM] = {1 + n * 0.01, 2 + n * 0.01};
        function(mapping, a);
    }
    end = clock();
    cpu_time1 = (double)(end - start) / CLOCKS_PER_SEC;
    printf("直接计算 f(T)(x) %d 次的计算时间：%lf\n", N, cpu_time1);

    start = clock();
    for (int n = 0; n < N; n++) {
        double a[DIM] = {1 + n * 0.01, 2 + n * 0.01};
        double b[DIM];
        mapping(a, b);
    }
    end = clock();
    cpu_time2 = (double)(end - start) / CLOCKS_PER_SEC;
    printf("利用理论框架计算 f(T)(x) %d 次的计算时间：%lf\n", N, cpu_time2);

    return 0;
}