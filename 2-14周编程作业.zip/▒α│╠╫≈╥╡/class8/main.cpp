#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define DIM 2 // 定义向量空间的维度

// 定义内积函数
double inner_product(double u[], double v[]) {
    double sum = 0.0;
    for (int i = 0; i < DIM; i++) {
        sum += u[i] * v[i];
    }
    return sum;
}

// 列向量的lp范数
double column_vector_norm(double x[], int p) {
    if (p == __INT_MAX__) { // 无穷范数
        double max_val = 0.0;
        for (int i = 0; i < DIM; i++) {
            if (fabs(x[i]) > max_val) {
                max_val = fabs(x[i]);
            }
        }
        return max_val;
    }
    double sum = 0.0;
    for (int i = 0; i < DIM; i++) {
        sum += pow(fabs(x[i]), p);
    }
    return pow(sum, 1.0 / p);
}

// 线性变换函数
void mapping(double x[], double y[]) {
    double A[DIM][DIM] = {{0.2, 0}, {0.5, 0.4}};
    double Ax[DIM];
    double xTx[DIM];
    for (int i = 0; i < DIM; i++) {
        Ax[i] = 0.0;
        xTx[i] = 0.0;
        for (int j = 0; j < DIM; j++) {
            Ax[i] += A[i][j] * x[j];
            xTx[i] += x[i] * x[j];
        }
    }
    for (int i = 0; i < DIM; i++) {
        y[i] = Ax[i] + xTx[i] * 0.2;
    }
}

int main() {
    // 初始化向量
    double x[DIM] = {4, -3};

    // 计算范数
    int p = __INT_MAX__; // 无穷范数
    printf("\n列向量x的无穷范数=%lf\n", column_vector_norm(x, p));

    p = 1; // l1范数
    printf("列向量x的l1范数=%lf\n", column_vector_norm(x, p));

    p = 2; // l2范数
    printf("列向量x的l2范数=%lf\n", column_vector_norm(x, p));

    // 设计一个收敛的过程
    printf("\n设计一个收敛过程,实现：a_k->a <=> ||a_k||->||a||， a = 0\n");
    double y[DIM];
    for (int k = 0; k < 20; k++) {
        mapping(x, y);
        for (int i = 0; i < DIM; i++) {
            x[i] = y[i];
        }
        printf("%d: %lf\n", k, column_vector_norm(x, 2));
    }

    return 0;
}