#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <lapacke.h>

//需要再linux下配置lapack才能使用
// sudo apt-get install liblapack-dev
// 满秩分解（普通满秩分解）
void full_rank_decomposition(double *A, int m, int n, double *F, double *G) {
    lapack_int info, lda = m, ldb = m, ldc = m;
    lapack_int rank = LAPACKE_dgeqrf(LAPACK_ROW_MAJOR, m, n, A, lda, NULL);

    double *tau = (double *)malloc(n * sizeof(double));
    double *R = (double *)malloc(n * n * sizeof(double));
    double *F_work = (double *)malloc(m * n * sizeof(double));

    // QR分解
    info = LAPACKE_dgeqrf(LAPACK_ROW_MAJOR, m, n, A, lda, tau);
    info = LAPACKE_dorgqr(LAPACK_ROW_MAJOR, m, n, rank, A, lda, tau, F_work, ldb);

    // 将QR分解的结果赋值给F和G
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            F[i * n + j] = F_work[i * n + j];
        }
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            R[i * n + j] = A[i * n + j];
        }
    }

    free(tau);
    free(R);
    free(F_work);
}

// 列主元满秩分解
void column_pivoting_full_rank_decomposition(double *A, int m, int n, double *P, double *B, double *C) {
    // 此函数需要实现列主元LU分解，并根据分解结果计算P、B、C
    // 由于LAPACKE不直接提供列主元LU分解，这里省略具体实现
}

// QR分解
void qr_decomposition(double *A, int m, int n, double *Q, double *R) {
    lapack_int info, lda = m, ldb = m, ldc = m;
    double *tau = (double *)malloc(n * sizeof(double));

    // QR分解
    info = LAPACKE_dgeqrf(LAPACK_ROW_MAJOR, m, n, A, lda, tau);

    // 将QR分解的结果赋值给Q和R
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            Q[i * n + j] = A[i * n + j];
        }
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            R[i * n + j] = A[i * n + j];
        }
    }

    free(tau);
}

// 利用QR分解求SVD分解中最后一步：把U1扩充成酉矩阵U
void svd_last_step(double *U1, int m, int n, double *U) {
    // 此函数需要实现将U1扩充成酉矩阵U的过程
    // 由于涉及到复杂的线性代数操作，这里省略具体实现
}

// SVD分解
void svd_decomposition(double *A, int m, int n, double *U, double *D, double *V) {
    lapack_int info, lda = m, ldb = m, ldc = m;
    lapack_int rank = LAPACKE_dgeqrf(LAPACK_ROW_MAJOR, m, n, A, lda, NULL);

    double *S = (double *)malloc(min(m, n) * sizeof(double));
    double *V_temp = (double *)malloc(n * n * sizeof(double));
    lapack_int *iwork = (lapack_int *)malloc(8 * min(m, n) * sizeof(lapack_int));
    double *work = (double *)malloc(3 * min(m, n) * sizeof(double));

    // SVD分解
    info = LAPACKE_dgesvd(LAPACK_ROW_MAJOR, 'A', 'A', m, n, A, lda, S, U, m, V_temp, n, work, iwork);

    // 将SVD分解的结果赋值给U, D和V
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < min(m, n); j++) {
            U[i * min(m, n) + j] = U[i * min(m, n) + j];
        }
    }
    for (int i = 0; i < min(m, n); i++) {
        D[i] = S[i];
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            V[i * n + j] = V_temp[i * n + j];
        }
    }

    free(S);
    free(V_temp);
    free(iwork);
    free(work);
}

int main() {
    // 示例：如何调用这些函数
    int m = 4; // 行数
    int n = 3; // 列数
    double A[12] = {-1, 0, 1, 2, 1, 2, -1, 1, 2, 2, -2, -1}; // 测试矩阵A
    double F[12] = {0}; // 普通满秩分解结果F
    double G[12] = {0}; // 普通满秩分解结果G
    double P[12] = {0}; // 列主元满秩分解结果P
    double B[12] = {0}; // 列主元满秩分解结果B
    double C[12] = {0}; // 列主元满秩分解结果C
    double Q[12] = {0}; // QR分解结果Q
    double R[9] = {0};  // QR分解结果R
    double U[12] = {0}; // SVD分解结果U
    double D[3] = {0};  // SVD分解结果D
    double V[9] = {0};  // SVD分解结果V

    full_rank_decomposition(A, m, n, F, G);
    qr_decomposition(A, m, n, Q, R);
    svd_decomposition(A, m, n, U, D, V);

    // 输出结果
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            printf("F[%d][%d] = %f\n", i, j, F[i * n + j]);
            printf("G[%d][%d] = %f\n", i, j, G[i * n + j]);
        }
    }
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            printf("Q[%d][%d] = %f\n", i, j, Q[i * n + j]);
        }
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("R[%d][%d] = %f\n", i, j, R[i * n + j]);
        }
    }
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            printf("U[%d][%d] = %f\n", i, j, U[i * n + j]);
        }
    }
    for (int i = 0; i < min(m, n); i++) {
        printf("D[%d] = %f\n", i, D[i]);
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("V[%d][%d] = %f\n", i, j, V[i * n + j]);
        }
    }

    return 0;
}