#include <stdio.h>
#include <stdlib.h>

// 定义线性空间结构体
typedef struct {
    double **basis; // 基向量数组
    int dim;       // 维数
} LinearSpace;

// 初始化线性空间
void initLinearSpace(LinearSpace *ls, double **basis, int dim) {
    ls->basis = basis;
    ls->dim = dim;
}

// 获取线性空间的维数
int getDim(LinearSpace *ls) {
    return ls->dim;
}

// 定义元素结构体
typedef struct {
    LinearSpace *ls;       // 所属线性空间
    double *coordinate;    // 坐标
} Element;

// 初始化元素
void initElement(Element *e, LinearSpace *ls, double *coordinate) {
    e->ls = ls;
    e->coordinate = coordinate;
}

// 计算元素的数值
double value(Element *e) {
    double v = e->ls->basis[0][0] * e->coordinate[0];
    for (int k = 1; k < e->ls->dim; k++) {
        v += e->ls->basis[k][0] * e->coordinate[k];
    }
    return v;
}

// 定义线性变换结构体
typedef struct {
    LinearSpace *ls;       // 线性空间
    double **matrix;       // 变换矩阵
} LinearTransformation;

// 初始化线性变换
void initLinearTransformation(LinearTransformation *lt, LinearSpace *ls, double **matrix) {
    lt->ls = ls;
    lt->matrix = matrix;
}

// 执行线性变换
Element linearTrans(LinearTransformation *lt, Element *input_ele) {
    Element output_ele;
    output_ele.ls = input_ele->ls;
    output_ele.coordinate = (double *)malloc(sizeof(double) * lt->ls->dim);
    for (int i = 0; i < lt->ls->dim; i++) {
        output_ele.coordinate[i] = 0;
        for (int j = 0; j < lt->ls->dim; j++) {
            output_ele.coordinate[i] += lt->matrix[i][j] * input_ele->coordinate[j];
        }
    }
    return output_ele;
}

// 基本的线性变换函数
void mapping(double **x) {
    double temp = x[0][0];
    x[0][0] = x[0][1];
    x[0][1] = temp;
}

// 线性变换的函数
double function(double **x) {
    double result1, result2;
    double *temp_x = (double *)malloc(sizeof(double) * 2); // 临时存储x的值
    temp_x[0] = x[0][0];
    temp_x[1] = x[0][1];

    mapping(x); // 应用映射
    result1 = x[0][0] + x[0][1]; // 计算T(x)
    mapping(x); // 再次应用映射
    result2 = x[0][0] + x[0][1]; // 计算T(T(x))

    double y = result1 + 2 * result2; // 计算T(T(T(x))) + 2 * T(x)
    free(temp_x);
    return y;
}

int main() {
    // 定义基向量和数域
    double basis[4][2] = {{1, 0}, {1, 0}, {-1, 0}, {0, 1}};
    LinearSpace ls;
    initLinearSpace(&ls, (double **)basis, 4);

    // 定义元素的坐标
    double alpha[4] = {0.5 * (1 + 3), 0.5 * (2 + 4), 0.5 * (-1 + 3), 0.5 * (-2 + 4)};
    Element a;
    initElement(&a, &ls, alpha);

    // 定义线性变换矩阵
    double matrix[4][4] = {
            {1, 0, 0, 0},
            {0, 1, 0, 0},
            {0, 0, -1, 0},
            {0, 0, 0, -1}
    };
    LinearTransformation lt;
    initLinearTransformation(&lt, &ls, (double **)matrix);

    // 执行线性变换
    Element b = linearTrans(&lt, &a);
    printf("Result: %lf\n", value(&b));

    // 清理分配的内存
    free(b.coordinate);

    return 0;
}