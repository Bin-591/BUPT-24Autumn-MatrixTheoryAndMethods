#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX_DIM 3

// 定义线性空间结构体
typedef struct {
    double basis[MAX_DIM][MAX_DIM]; // 基向量数组
    int dim;                       // 维数
} LinearSpace;

// 定义元素结构体
typedef struct {
    LinearSpace *ls;                // 所属线性空间
    double coordinate[MAX_DIM];     // 坐标
} Element;

// 定义线性变换结构体
typedef struct {
    LinearSpace *ls;                // 线性空间
    double matrix[MAX_DIM][MAX_DIM]; // 变换矩阵
} LinearTransformation;

// 内积函数
double inner_product(double u[MAX_DIM], double v[MAX_DIM]) {
    double sum = 0.0;
    for (int i = 0; i < MAX_DIM; i++) {
        sum += u[i] * v[i];
    }
    return sum;
}

// 施密特正交化方法
void gram_schmidt(LinearSpace *ls) {
    for (int i = 0; i < ls->dim; i++) {
        // 归一化
        double norm = sqrt(inner_product(ls->basis[i], ls->basis[i]));
        for (int j = 0; j < ls->dim; j++) {
            ls->basis[i][j] /= norm;
        }

        // 移除其他向量在当前向量上的投影
        for (int k = i + 1; k < ls->dim; k++) {
            double proj = inner_product(ls->basis[i], ls->basis[k]);
            for (int j = 0; j < ls->dim; j++) {
                ls->basis[k][j] -= proj * ls->basis[i][j];
            }
        }
    }
}

// 初始化线性空间
void initLinearSpace(LinearSpace *ls, double basis[MAX_DIM][MAX_DIM], int dim) {
    ls->dim = dim;
    for (int i = 0; i < dim; i++) {
        for (int j = 0; j < dim; j++) {
            ls->basis[i][j] = basis[i][j];
        }
    }
    gram_schmidt(ls);
}

// 计算元素的数值
double value(Element *e) {
    double v = 0.0;
    for (int i = 0; i < e->ls->dim; i++) {
        v += e->coordinate[i] * e->ls->basis[i][0];
    }
    return v;
}

// 计算元素在标准正交基下的坐标
void coordinate(Element *e, LinearSpace *ls, double value[MAX_DIM]) {
    for (int i = 0; i < ls->dim; i++) {
        e->coordinate[i] = inner_product(ls->basis[i], value);
    }
}

// 线性变换在标准正交基下的矩阵
void trans2matrix(LinearTransformation *lt, LinearSpace *ls, double (*transformation)(double)) {
    for (int i = 0; i < ls->dim; i++) {
        double transformed[MAX_DIM];
        transformed[0] = transformation(ls->basis[i][0]);
        for (int j = 1; j < ls->dim; j++) {
            transformed[j] = 0.0; // 根据实际变换填充
        }
        for (int j = 0; j < ls->dim; j++) {
            lt->matrix[j][i] = inner_product(ls->basis[j], transformed);
        }
    }
}

// 基本的线性变换
double mapping(double x) {
    return x + 1.0; // 示例变换
}

int main() {
    // 初始化线性空间
    double basis[MAX_DIM][MAX_DIM] = {
            {-1, 1, 0},
            {-1, 0, 1},
            {0, 0, 0}
    };
    LinearSpace ls;
    initLinearSpace(&ls, basis, 3);

    // 计算元素在标准正交基下的坐标
    double x[MAX_DIM] = {4, -4, 0};
    Element e;
    e.ls = &ls;
    coordinate(&e, &ls, x);
    printf("x在标准正交基下的坐标:\n");
    for (int i = 0; i < ls.dim; i++) {
        printf("%lf\n", e.coordinate[i]);

        // 计算线性变换在标准正交基下的矩阵
        LinearTransformation lt;
        lt.ls = &ls;
        trans2matrix(&lt, &ls, mapping);
        printf("线性变换在标准正交基下的矩阵:\n");
        for (int i = 0; i < ls.dim; i++) {
            for (int j = 0; j < ls.dim; j++) {
                printf("%lf ", lt.matrix[i][j]);
            }
            printf("\n");
        }
    }

    return 0;
}