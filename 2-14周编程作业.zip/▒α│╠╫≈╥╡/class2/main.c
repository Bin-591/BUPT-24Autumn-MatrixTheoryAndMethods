#include <stdio.h>
#include <stdlib.h>
#include <complex.h>

// 定义线性空间结构体
typedef struct {
    complex double* basis; // 基
    int dim;              // 维数
} LinearSpace;

// 定义元素结构体
typedef struct {
    LinearSpace* space;
    complex double* coordinate;
    int dim;
} Element;

// 定义线性变换结构体
typedef struct {
    LinearSpace* space;
    complex double* matrix;
    int dim;
} LinearTransformation;

// 初始化线性空间
LinearSpace* initLinearSpace(complex double* basis, int dim) {
    LinearSpace* ls = (LinearSpace*)malloc(sizeof(LinearSpace));
    ls->basis = basis;
    ls->dim = dim;
    return ls;
}

// 初始化元素
Element* initElement(LinearSpace* space, complex double* coordinate) {
    Element* ele = (Element*)malloc(sizeof(Element));
    ele->space = space;
    ele->coordinate = coordinate;
    ele->dim = space->dim;
    return ele;
}

// 初始化线性变换
LinearTransformation* initLinearTransformation(LinearSpace* space, complex double* matrix) {
    LinearTransformation* lt = (LinearTransformation*)malloc(sizeof(LinearTransformation));
    lt->space = space;
    lt->matrix = matrix;
    lt->dim = space->dim;
    return lt;
}

// 计算元素的值
complex double calculateValue(Element* ele) {
    complex double value = 0;
    for (int i = 0; i < ele->dim; i++) {
        value += ele->coordinate[i] * ele->space->basis[i];
    }
    return value;
}

// 应用线性变换
void applyTransformation(LinearTransformation* lt, Element* input, Element* output) {
    complex double* result = (complex double*)malloc(sizeof(complex double) * lt->dim);
    for (int i = 0; i < lt->dim; i++) {
        result[i] = 0;
        for (int j = 0; j < lt->dim; j++) {
            result[i] += lt->matrix[i * lt->dim + j] * input->coordinate[j];
        }
    }
    output->coordinate = result;
}

int main() {
    // 定义基和数域
    complex double basis[] = {1.0 + 0.0 * I, 0.0 + 1.0 * I};
    int dim = 2;
    LinearSpace* space = initLinearSpace(basis, dim);

    // 定义元素
    complex double coordinate[] = {3.0 + 0.0 * I, 4.0 + 0.0 * I};
    Element* element = initElement(space, coordinate);

    // 定义线性变换矩阵
    complex double matrix[] = {1.0 + 0.0 * I, -2.0 + 0.0 * I, 2.0 + 0.0 * I, 1.0 + 0.0 * I};
    LinearTransformation* transformation = initLinearTransformation(space, matrix);

    // 计算元素的值
    complex double value = calculateValue(element);
    printf("Element value: %f + %fi\n", creal(value), cimag(value));

    // 应用线性变换
    Element* transformedElement = initElement(space, NULL);
    applyTransformation(transformation, element, transformedElement);
    printf("Transformed element: ");
    for (int i = 0; i < dim; i++) {
        printf("%f + %fi ", creal(transformedElement->coordinate[i]), cimag(transformedElement->coordinate[i]));
    }
    printf("\n");

    // 释放内存
    free(space);
    free(element);
    free(transformedElement);
    free(transformation);

    return 0;
}