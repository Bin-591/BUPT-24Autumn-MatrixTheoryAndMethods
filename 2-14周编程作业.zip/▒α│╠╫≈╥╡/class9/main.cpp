#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define ROWS 2
#define COLS 2

// 计算矩阵的无穷范数
double infinity_norm(double A[ROWS][COLS]) {
    double max_sum = 0.0;
    for (int i = 0; i < ROWS; i++) {
        double row_sum = 0.0;
        for (int j = 0; j < COLS; j++) {
            row_sum += fabs(A[i][j]);
        }
        if (row_sum > max_sum) {
            max_sum = row_sum;
        }
    }
    return max_sum;
}

// 计算矩阵的1范数
double one_norm(double A[ROWS][COLS]) {
    double max_sum = 0.0;
    for (int j = 0; j < COLS; j++) {
        double col_sum = 0.0;
        for (int i = 0; i < ROWS; i++) {
            col_sum += fabs(A[i][j]);
        }
        if (col_sum > max_sum) {
            max_sum = col_sum;
        }
    }
    return max_sum;
}

// 计算矩阵的Frobenius范数
double frobenius_norm(double A[ROWS][COLS]) {
    double sum = 0.0;
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            sum += A[i][j] * A[i][j];
        }
    }
    return sqrt(sum);
}

// 计算矩阵的条件数
double condition_number(double A[ROWS][COLS]) {
    // 这里简化处理，仅计算2x2矩阵的条件数
    double det = A[0][0] * A[1][1] - A[0][1] * A[1][0];
    double inv_det = 1.0 / det;
    double A_inv[ROWS][COLS];
    A_inv[0][0] =  A[1][1] * inv_det;
    A_inv[0][1] = -A[0][1] * inv_det;
    A_inv[1][0] = -A[1][0] * inv_det;
    A_inv[1][1] =  A[0][0] * inv_det;

    double cond_num = infinity_norm(A) * infinity_norm(A_inv);
    return cond_num;
}

// 计算矩阵的谱半径
double spectral_radius(double A[ROWS][COLS]) {
    double max_real_part = 0.0;
    for (int i = 0; i < ROWS; i++) {
        double trace = 0.0;
        for (int j = 0; j < COLS; j++) {
            trace += A[j][i];
        }
        max_real_part = fmax(max_real_part, fabs(trace));
    }
    return max_real_part;
}

// 判断矩阵是否为收敛矩阵
int is_convergent(double A[ROWS][COLS]) {
    return spectral_radius(A) < 1.0;
}

int main() {
    double A[ROWS][COLS] = {{6.0, 7}, {3.0, 1.0}};
    double B[ROWS][COLS] = {{0.3174999, 0.39}, {0.7, 0.6}};

    printf("矩阵A的无穷范数: %lf\n", infinity_norm(A));
    printf("矩阵A的1范数: %lf\n", one_norm(A));
    printf("矩阵A的Frobenius范数: %lf\n", frobenius_norm(A));
    printf("矩阵A的条件数: %lf\n", condition_number(A));
    printf("矩阵A的谱半径: %lf\n", spectral_radius(A));
    printf("矩阵A是否为收敛矩阵: %d\n", is_convergent(A));

    printf("\n矩阵B的谱半径: %lf\n", spectral_radius(B));
    printf("矩阵B是否为收敛矩阵: %d\n", is_convergent(B));

    return 0;
}