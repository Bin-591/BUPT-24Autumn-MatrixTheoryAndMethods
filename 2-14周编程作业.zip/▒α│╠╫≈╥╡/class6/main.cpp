#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define DIM 4 // 定义向量空间的维度

// 定义内积函数
double inner_product(double u[], double v[]) {
    double sum = 0.0;
    for (int i = 0; i < DIM; i++) {
        sum += u[i] * v[i];
    }
    return sum;
}

// 定义归一化函数
void normalize_vector(double v[]) {
    double norm = sqrt(inner_product(v, v));
    for (int i = 0; i < DIM; i++) {
        v[i] /= norm;
    }
}

// 施密特正交化过程
void gram_schmidt(double basis[][DIM], int num_vectors) {
    for (int m = 0; m < num_vectors; m++) {
        // 正交化
        double ym1[DIM];
        for (int i = 0; i < DIM; i++) {
            ym1[i] = basis[m + 1][i];
        }
        for (int i = 0; i <= m; i++) {
            double li = -inner_product(basis[m + 1], basis[i]) / inner_product(basis[i], basis[i]);
            for (int j = 0; j < DIM; j++) {
                ym1[j] += li * basis[i][j];
            }
        }
        for (int i = 0; i < DIM; i++) {
            basis[m + 1][i] = ym1[i];
        }
        // 单位化
        normalize_vector(basis[m + 1]);
    }
}

int main() {
    // 初始化向量
    double basis[DIM][DIM] = {
            {1, 1, 0, 0},
            {1, 0, 1, 0},
            {-1, 0, 0, 1},
            {1, -1, -1, 1}
    };

    // 正交单位化
    gram_schmidt(basis, DIM);

    // 打印结果
    printf("标准正交基(e1,e2,e3,e4)=\n");
    for (int i = 0; i < DIM; i++) {
        for (int j = 0; j < DIM; j++) {
            printf("%lf ", basis[i][j]);
        }
        printf("\n");
    }

    return 0;
}