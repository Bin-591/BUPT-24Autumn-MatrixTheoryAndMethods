#include <stdio.h>
#include <stdlib.h>
#include <lapacke.h>
//需要安装LapAck库实现
//sudo apt-get install liblapack-dev
#define MAT_SIZE 3 // 根据实际矩阵大小定义

int main() {
    // 定义矩阵A
    double A[MAT_SIZE][MAT_SIZE] = {
            {-1, 1, 0},
            {-4, 3, 0},
            {1, 0, 2}
    };

    // 用于存放Jordan标准形的矩阵
    double J[MAT_SIZE][MAT_SIZE];

    // 用于存放相似变换矩阵P
    double P[MAT_SIZE][MAT_SIZE];

    // 用于存放P的逆矩阵
    double invP[MAT_SIZE][MAT_SIZE];

    // 工作空间和信息变量
    int info, lda = MAT_SIZE, ldv = MAT_SIZE;
    double work[3*MAT_SIZE];
    int lwork = 3*MAT_SIZE;
    int ifst = 1, ilst = 1;
    int m, i;

    // 计算Jordan标准形
    info = LAPACKE_dgees_work(LAPACK_ROW_MAJOR, 'V', 'N', LAPACKE_lsame('N', "S"), LAPACKE_lsame('N","S"), NULL, A, lda, &m, J, lda, P, ldv, work, lwork, &ifst, &ilst, (int[]){0}, (int[]){0});
    if (info != 0) {
        printf("计算Jordan标准形失败。\n");
        return EXIT_FAILURE;
    }

    // 计算P的逆矩阵
    info = LAPACKE_dgetrf(LAPACK_ROW_MAJOR, MAT_SIZE, MAT_SIZE, P, ldv, (int[]){0}, &info);
    if (info != 0) {
        printf("计算P的逆矩阵失败。\n");
        return EXIT_FAILURE;
    }

    info = LAPACKE_dgetri(LAPACK_ROW_MAJOR, MAT_SIZE, P, ldv, (int[]){0}, work, &info);
    if (info != 0) {
        printf("计算P的逆矩阵失败。\n");
        return EXIT_FAILURE;
    }

    // 打印结果
    printf("矩阵A的Jordan标准形J:\n");
    for (i = 0; i < MAT_SIZE; i++) {
        for (int j = 0; j < MAT_SIZE; j++) {
            printf("%lf ", J[i][j]);
        }
        printf("\n");
    }

    printf("相似变换矩阵P:\n");
    for (i = 0; i < MAT_SIZE; i++) {
        for (int j = 0; j < MAT_SIZE; j++) {
            printf("%lf ", P[i][j]);
        }
        printf("\n");
    }

    printf("P的逆矩阵invP:\n");
    for (i = 0; i < MAT_SIZE; i++) {
        for (int j = 0; j < MAT_SIZE; j++) {
            printf("%lf ", invP[i][j]);
        }
        printf("\n");
    }

    return 0;
}