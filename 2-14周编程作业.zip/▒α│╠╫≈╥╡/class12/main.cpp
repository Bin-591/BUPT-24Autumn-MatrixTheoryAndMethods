#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define N 3000

// 函数声明
void generateVectorB(double *b);
void generateCirculantMatrix(double **A, double *a0);
void circulantMatrixInverse(double **A, double **invA, int N);
void matrixMultiply(double **A, double *x, double *b, int N);
double **allocateMatrix(int rows, int cols);
void freeMatrix(double **matrix, int rows);

int main() {
    double *A[N], *invA[N], *b, *x;
    clock_t start, end;
    double cpu_time_used;

    // 初始化随机数种子
    srand(time(NULL));

    // 动态分配内存
    b = (double *)malloc(N * sizeof(double));
    x = (double *)malloc(N * sizeof(double));
    for (int i = 0; i < N; i++) {
        A[i] = (double *)malloc(N * sizeof(double));
        invA[i] = (double *)malloc(N * sizeof(double));
    }

    // 生成向量b
    generateVectorB(b);

    // 生成循环矩阵A
    generateCirculantMatrix(A, b);

    // 计算A的逆
    circulantMatrixInverse(A, invA, N);

    // 计算x = A^-1 * b
    matrixMultiply(invA, x, b, N);

    // 计算并打印时间
    start = clock();
    matrixMultiply(invA, x, b, N);
    end = clock();
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("直接求逆计算时间为%f秒\n", cpu_time_used);

    // 释放内存
    free(b);
    free(x);
    for (int i = 0; i < N; i++) {
        free(A[i]);
        free(invA[i]);
    }
    free(A);
    free(invA);

    return 0;
}

// 生成随机向量b
void generateVectorB(double *b) {
    for (int i = 0; i < N; i++) {
        b[i] = (double)rand() / RAND_MAX;
    }
}

// 生成循环矩阵A
void generateCirculantMatrix(double **A, double *a0) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            A[i][j] = a0[(j + i) % N];
        }
    }
}

// 计算循环矩阵A的逆
void circulantMatrixInverse(double **A, double **invA, int N) {
// 这里需要实现循环矩阵的求逆算法，可以使用FFT等方法
// 为了简化，这里不实现具体的求逆算法，只提供一个框架
for (int i = 0; i < N; i++) {
for (int j = 0; j < N; j++) {
// 这里应该是计算A的逆的代码
// invA[i][j] = ...
}
}
}

// 矩阵乘法
void matrixMultiply(double **A, double *x, double *b, int N) {
for (int i = 0; i < N; i++) {
x[i] = 0;
for (int j = 0; j < N; j++) {
x[i] += A[i][j] * b[j];
}
}
}

// 动态分配矩阵内存
double **allocateMatrix(int rows, int cols) {
    double **matrix = (double **)malloc(rows * sizeof(double *));
    for (int i = 0; i < rows; i++) {
        matrix[i] = (double *)malloc(cols * sizeof(double));
    }
    return matrix;
}

// 释放矩阵内存
void freeMatrix(double **matrix, int rows) {
    for (int i = 0; i < rows; i++) {
        free(matrix[i]);
    }
    free(matrix);
}