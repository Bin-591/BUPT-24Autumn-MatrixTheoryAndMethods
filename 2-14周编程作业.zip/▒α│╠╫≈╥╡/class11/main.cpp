#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 100
#define K 2

// 函数声明
void generateData(double x[N][K], double y[N]);
void linearRegression(double X[N][K+1], double Y[N], double W[K+1]);
void pseudoInverse(double X[N][K+1], double Y[N], double W[K+1]);

int main() {
    double x_data[N][K], y_data[N], W[K+1];
    double X[N][K+1];

    // 生成数据
    generateData(x_data, y_data);

    // 将数据转换为X和Y矩阵
    for (int i = 0; i < N; i++) {
        X[i][0] = x_data[i][0];
        X[i][1] = x_data[i][1];
        X[i][2] = 1.0; // 添加截距项
    }

    // 最小二乘法计算系数
    linearRegression(X, y_data, W);
    printf("最小二乘法计算系数：\n");
    printf("w1 = %f, w2 = %f, b = %f\n", W[0], W[1], W[2]);

    // 使用广义逆求解系数
    pseudoInverse(X, y_data, W);
    printf("广义逆求解系数：\n");
    printf("w1 = %f, w2 = %f, b = %f\n", W[0], W[1], W[2]);

    return 0;
}

// 生成数据
void generateData(double x[N][K], double y[N]) {
    for (int i = 0; i < N; i++) {
        x[i][0] = (double)rand() / RAND_MAX;
        x[i][1] = (double)rand() / RAND_MAX;
        y[i] = 0.100 * x[i][0] + 0.200 * x[i][1] + 0.300 + ((double)rand() / RAND_MAX - 0.5) / 10.0;
    }
}

// 最小二乘法计算系数
void linearRegression(double X[N][K+1], double Y[N], double W[K+1]) {
    double XTX[K+1][K+1], XTY[K+1];
    double invXTX[K+1][K+1];
    double det;

    // 计算XTX和XTY
    for (int i = 0; i < K+1; i++) {
        for (int j = 0; j < K+1; j++) {
            XTX[i][j] = 0;
            for (int k = 0; k < N; k++) {
                XTX[i][j] += X[k][i] * X[k][j];
            }
        }
        XTY[i] = 0;
        for (int k = 0; k < N; k++) {
            XTY[i] += X[k][i] * Y[k];
        }
    }

    // 计算XTX的逆
    det = 1.0 / (XTX[0][0] * (XTX[1][1] * XTX[2][2] - XTX[1][2] * XTX[2][1]) - XTX[0][1] * (XTX[1][0] * XTX[2][2] - XTX[1][2] * XTX[2][0]) + XTX[0][2] * (XTX[1][0] * XTX[2][1] - XTX[1][1] * XTX[2][0]));

    for (int i = 0; i < K+1; i++) {
        for (int j = 0; j < K+1; j++) {
            double temp = 0;
            for (int k = 0; k < K+1; k++) {
                for (int l = 0; l < K+1; l++) {
                    if (k != i || l != j) temp += XTX[k][l] * invXTX[l][i];
                }
            }
            invXTX[j][i] = -temp * det;
            if (i == j) invXTX[j][i] += 1;
        }
    }

    // 计算W = inv(XTX) * XTY
    for (int i = 0; i < K+1; i++) {
        W[i] = 0;
        for (int j = 0; j < K+1; j++) {
            W[i] += invXTX[i][j] * XTY[j];
        }
    }
}

// 使用广义逆求解系数
void pseudoInverse(double X[N][K+1], double Y[N], double W[K+1]) {
    double X_pseudo[N][K+1];
    double XTX[K+1][K+1], XTY[K+1];
    double invXTX[K+1][K+1];
    double det;

    // 计算XTX和XTY
    for (int i = 0; i < K+1; i++) {
        for (int j = 0; j < K+1; j++) {
            XTX[i][j] = 0;
            for (int k = 0; k < N; k++) {
                XTX[i][j] += X[k][i] * X[k][j];
            }
        }
        XTY[i] = 0;
        for (int k = 0; k < N; k++) {
            XTY[i] += X[k][i] * Y[k];
        }
    }

    // 计算XTX的逆
    det = 1.0 / (XTX[0][0] * (XTX[1][1] * XTX[2][2] - XTX[1][2] * XTX[2][1]) - XTX[0][1] * (XTX[1][0] * XTX[2][2] - XTX[1][2] * XTX[2][0]) + XTX[0][2] * (XTX[1][0] * XTX[2][1] - XTX[1][1] * XTX[2][0]));

    for (int i = 0; i < K+1; i++) {
        for (int j = 0; j < K+1; j++) {
            double temp = 0;
            for (int k = 0; k < K+1; k++) {
                for (int l = 0; l < K+1; l++) {
                    if (k != i || l != j) temp += XTX[k][l] * invXTX[l][i];
                }
            }
            invXTX[j][i] = -temp * det;
            if (i == j) invXTX[j][i] += 1;
        }
    }

    // 计算X的伪逆X_pseudo = inv(XTX) * X^T
    for (int i = 0; i < K+1; i++) {
        for (int j = 0; j < N; j++) {
            X_pseudo[i][j] = 0;
            for (int k = 0; k < K+1; k++) {
                X_pseudo[i][j] += invXTX[i][k] * X[k][j];
            }
        }
    }

    // 计算W = X_pseudo * Y
    for (int i = 0; i < K+1; i++) {
        W[i] = 0;
        for (int j = 0; j < N; j++) {
            W[i] += X_pseudo[i][j] * Y[j];
        }
    }
}